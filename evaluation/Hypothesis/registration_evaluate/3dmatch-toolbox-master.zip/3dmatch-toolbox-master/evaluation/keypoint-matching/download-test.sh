cd "$( dirname "${BASH_SOURCE[0]}" )"
wget http://vision.princeton.edu/projects/2016/3DMatch/downloads/keypoint-matching/test-set.mat