/* Include file for R2 draw utility */



inline void 
R2LoadPoint(const R2Point& point)
{
    // Load vertex 
    R2LoadPoint(point.Coords());
}



